
<?php phpinfo(); ?>

